#!/usr/bin/env python3
import sys
sys.path.insert(0, '/home/claude')
import z80asm
import z80dec

rom, symtab, max_addr_used, lines_info = z80asm.main()


def resolve(expr):
    return z80asm.eval_expr(expr, symtab)


REG8 = set(z80asm.REG8.keys()) | {'(hl)'}
REG16 = set(z80asm.REG16.keys())
COND8 = set(z80asm.COND8.keys())


def is_reg8(s):
    return s.lower() in REG8


def derive_intended(mnem, operand_str):
    """Independently derive the canonical text form of the intended
    instruction, in the same textual convention as z80dec.decode_one."""
    ops = z80asm.split_commas(operand_str) if operand_str.strip() else []
    m = mnem.lower()

    simple = {'nop': 'nop', 'halt': 'halt', 'di': 'di', 'ei': 'ei',
              'rra': 'rra', 'ldir': 'ldir', 'lddr': 'lddr', 'cpir': 'cpir',
              'ini': 'ini', 'outi': 'outi'}
    if m in simple and not ops:
        return simple[m]

    if m == 'ret':
        return 'ret' if not ops else f"ret {ops[0].lower()}"
    if m == 'push':
        return f"push {ops[0].lower()}"
    if m == 'pop':
        return f"pop {ops[0].lower()}"
    if m == 'ex':
        return f"ex {ops[0].lower()},{ops[1].lower()}"
    if m == 'djnz':
        return f"djnz {resolve(ops[0]) & 0xFFFF:#06x}"
    if m == 'jr':
        if len(ops) == 1:
            return f"jr {resolve(ops[0]) & 0xFFFF:#06x}"
        return f"jr {ops[0].lower()},{resolve(ops[1]) & 0xFFFF:#06x}"
    if m == 'jp':
        if len(ops) == 1:
            return f"jp {resolve(ops[0]) & 0xFFFF:#06x}"
        return f"jp {ops[0].lower()},{resolve(ops[1]) & 0xFFFF:#06x}"
    if m == 'call':
        if len(ops) == 1:
            return f"call {resolve(ops[0]) & 0xFFFF:#06x}"
        return f"call {ops[0].lower()},{resolve(ops[1]) & 0xFFFF:#06x}"
    if m in ('inc', 'dec'):
        return f"{m} {ops[0].lower()}"
    if m == 'add':
        o0 = ops[0].lower()
        if o0 == 'a':
            o1 = ops[1]
            if is_reg8(o1):
                return f"add a,{o1.lower()}"
            return f"add a,{resolve(o1) & 0xFF:#04x}"
        return f"add hl,{ops[1].lower()}"
    if m == 'sbc':
        o0 = ops[0].lower()
        if o0 == 'hl':
            return f"sbc hl,{ops[1].lower()}"
        o1 = ops[1]
        if is_reg8(o1):
            return f"sbc a,{o1.lower()}"
        return f"sbc a,{resolve(o1) & 0xFF:#04x}"
    if m in ('and', 'or', 'xor', 'sub', 'cp'):
        prefix = {'and': 'and ', 'or': 'or ', 'xor': 'xor ',
                  'sub': 'sub ', 'cp': 'cp '}[m]
        o0 = ops[0]
        if is_reg8(o0):
            return f"{prefix}{o0.lower()}"
        return f"{prefix}{resolve(o0) & 0xFF:#04x}"
    if m == 'srl':
        return f"srl {ops[0].lower()}"
    if m in ('bit', 'res', 'set'):
        b = resolve(ops[0])
        return f"{m} {b},{ops[1].lower()}"
    if m == 'out':
        o0 = ops[0].lower()
        if o0 == '(c)':
            return f"out (c),{ops[1].lower()}"
        n = resolve(ops[0][1:-1]) & 0xFF
        return f"out ({n:#04x}),a"
    if m == 'in':
        n = resolve(ops[1][1:-1]) & 0xFF
        return f"in a,({n:#04x})"
    if m == 'ld':
        dst, src = ops[0], ops[1]
        dstl, srcl = dst.lower(), src.lower()
        if dstl in REG8:
            if srcl in REG8:
                return f"ld {dstl},{srcl}"
            if dstl == 'a' and srcl == '(bc)':
                return "ld a,(bc)"
            if dstl == 'a' and srcl == '(de)':
                return "ld a,(de)"
            if dstl == 'a' and srcl.startswith('(') and srcl.endswith(')'):
                nn = resolve(src[1:-1]) & 0xFFFF
                return f"ld a,({nn:#06x})"
            n = resolve(src) & 0xFF
            return f"ld {dstl},{n:#04x}"
        if dstl == '(bc)' and srcl == 'a':
            return "ld (bc),a"
        if dstl == '(de)' and srcl == 'a':
            return "ld (de),a"
        if dstl.startswith('(') and dstl.endswith(')') and srcl == 'a':
            nn = resolve(dst[1:-1]) & 0xFFFF
            return f"ld ({nn:#06x}),a"
        if dstl in REG16:
            if srcl.startswith('(') and srcl.endswith(')'):
                nn = resolve(src[1:-1]) & 0xFFFF
                return f"ld {dstl},({nn:#06x})"
            if dstl == 'sp' and srcl == 'hl':
                return "ld sp,hl"
            n = resolve(src) & 0xFFFF
            return f"ld {dstl},{n:#06x}"
        if dstl.startswith('(') and dstl.endswith(')') and srcl in REG16:
            nn = resolve(dst[1:-1]) & 0xFFFF
            return f"ld ({nn:#06x}),{srcl}"
        raise ValueError(f"derive_intended: unhandled ld {dst},{src}")

    raise ValueError(f"derive_intended: unhandled mnemonic {mnem} {ops}")


mismatches = []
checked = 0
for label, mnem, operand_str, addr, equ_label in lines_info:
    ml = mnem.lower()
    if ml in ('', 'equ', '.z80', 'org', 'end', 'defb', 'defw', 'defs'):
        continue
    checked += 1
    try:
        intended = derive_intended(mnem, operand_str)
    except Exception as e:
        mismatches.append((addr, mnem, operand_str, f"derive-error: {e}", None))
        continue
    try:
        decoded, dlen = z80dec.decode_one(rom, addr)
    except Exception as e:
        mismatches.append((addr, mnem, operand_str, intended, f"decode-error: {e}"))
        continue
    if decoded != intended:
        mismatches.append((addr, mnem, operand_str, intended, decoded))

print(f"Checked {checked} instructions.")
print(f"Mismatches: {len(mismatches)}")
for addr, mnem, operand_str, intended, decoded in mismatches[:60]:
    print(f"  {addr:#06x}: source='{mnem} {operand_str}' intended='{intended}' decoded='{decoded}'")
