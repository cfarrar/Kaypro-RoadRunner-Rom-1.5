#!/usr/bin/env python3
"""
Independent Z80 decoder, written from the standard opcode maps (NOT sharing
any code/tables with z80asm.py), used purely to cross-check the encoder by
round-tripping: decode(encode(instr)) should describe the same instruction.
"""

R8 = ['b', 'c', 'd', 'e', 'h', 'l', '(hl)', 'a']
RP = ['bc', 'de', 'hl', 'sp']
RP2 = ['bc', 'de', 'hl', 'af']
CC = ['nz', 'z', 'nc', 'c', 'po', 'pe', 'p', 'm']
ALU = ['add a,', 'adc a,', 'sub ', 'sbc a,', 'and ', 'xor ', 'or ', 'cp ']


def s8(b):
    return b - 256 if b >= 128 else b


def decode_one(rom, addr):
    """Decode exactly one instruction at addr. Returns (mnemonic_text, length)."""
    b0 = rom[addr]

    if b0 == 0xCB:
        b1 = rom[addr + 1]
        x = b1 >> 6
        y = (b1 >> 3) & 7
        z = b1 & 7
        reg = R8[z]
        if x == 0:
            names = ['rlc', 'rrc', 'rl', 'rr', 'sla', 'sra', 'sll', 'srl']
            return f"{names[y]} {reg}", 2
        elif x == 1:
            return f"bit {y},{reg}", 2
        elif x == 2:
            return f"res {y},{reg}", 2
        else:
            return f"set {y},{reg}", 2

    if b0 == 0xED:
        b1 = rom[addr + 1]
        x = b1 >> 6
        y = (b1 >> 3) & 7
        z = b1 & 7
        if x == 1:
            if z == 0:
                return (f"in {'f' if y==6 else R8[y]},(c)"), 2
            if z == 1:
                return (f"out (c),{'0' if y==6 else R8[y]}"), 2
            if z == 2:
                op = 'sbc' if (y % 2 == 0) else 'adc'
                return f"{op} hl,{RP[y//2]}", 2
            if z == 3:
                lo, hi = rom[addr + 2], rom[addr + 3]
                nn = lo | (hi << 8)
                if y % 2 == 0:
                    return f"ld ({nn:#06x}),{RP[y//2]}", 4
                else:
                    return f"ld {RP[y//2]},({nn:#06x})", 4
            if z == 4:
                return "neg", 2
            if z == 5:
                return ("reti" if y == 1 else "retn"), 2
            if z == 6:
                return f"im {[0,0,1,2,0,0,1,2][y]}", 2
            if z == 7:
                names = {0: 'ld i,a', 1: 'ld r,a', 2: 'ld a,i', 3: 'ld a,r',
                         4: 'rrd', 5: 'rld', 6: 'nop(ed)', 7: 'nop(ed)'}
                return names[y], 2
        elif x == 2 and z <= 3 and y >= 4:
            names = [['ldi', 'cpi', 'ini', 'outi'],
                     ['ldd', 'cpd', 'ind', 'outd'],
                     ['ldir', 'cpir', 'inir', 'otir'],
                     ['lddr', 'cpdr', 'indr', 'otdr']]
            return names[y - 4][z], 2
        return f"DB 0edh,{b1:#04x}", 2

    x = b0 >> 6
    y = (b0 >> 3) & 7
    z = b0 & 7
    p = y >> 1
    q = y & 1

    if x == 0:
        if z == 0:
            if y == 0:
                return "nop", 1
            if y == 1:
                return "ex af,af'", 1
            if y == 2:
                d = s8(rom[addr + 1])
                return f"djnz {addr+2+d:#06x}", 2
            if y == 3:
                d = s8(rom[addr + 1])
                return f"jr {addr+2+d:#06x}", 2
            d = s8(rom[addr + 1])
            return f"jr {CC[y-4]},{addr+2+d:#06x}", 2
        if z == 1:
            if q == 0:
                lo, hi = rom[addr + 1], rom[addr + 2]
                return f"ld {RP[p]},{(lo|(hi<<8)):#06x}", 3
            else:
                return f"add hl,{RP[p]}", 1
        if z == 2:
            forms = ['ld (bc),a', 'ld a,(bc)', 'ld (de),a', 'ld a,(de)',
                     None, None, None, None]
            if p == 0:
                return forms[q], 1
            if p == 1:
                return forms[2 + q], 1
            if p == 2:
                lo, hi = rom[addr + 1], rom[addr + 2]
                nn = lo | (hi << 8)
                return (f"ld ({nn:#06x}),hl" if q == 0 else f"ld hl,({nn:#06x})"), 3
            if p == 3:
                lo, hi = rom[addr + 1], rom[addr + 2]
                nn = lo | (hi << 8)
                return (f"ld ({nn:#06x}),a" if q == 0 else f"ld a,({nn:#06x})"), 3
        if z == 3:
            return (f"inc {RP[p]}" if q == 0 else f"dec {RP[p]}"), 1
        if z == 4:
            return f"inc {R8[y]}", 1
        if z == 5:
            return f"dec {R8[y]}", 1
        if z == 6:
            n = rom[addr + 1]
            return f"ld {R8[y]},{n:#04x}", 2
        if z == 7:
            names = ['rlca', 'rrca', 'rla', 'rra', 'daa', 'cpl', 'scf', 'ccf']
            return names[y], 1

    if x == 1:
        if y == 6 and z == 6:
            return "halt", 1
        return f"ld {R8[y]},{R8[z]}", 1

    if x == 2:
        return f"{ALU[y]}{R8[z]}", 1

    if x == 3:
        if z == 0:
            return f"ret {CC[y]}", 1
        if z == 1:
            if q == 0:
                return f"pop {RP2[p]}", 1
            if p == 0:
                return "ret", 1
            if p == 1:
                return "exx", 1
            if p == 2:
                return "jp (hl)", 1
            if p == 3:
                return "ld sp,hl", 1
        if z == 2:
            lo, hi = rom[addr + 1], rom[addr + 2]
            nn = lo | (hi << 8)
            return f"jp {CC[y]},{nn:#06x}", 3
        if z == 3:
            if y == 0:
                lo, hi = rom[addr + 1], rom[addr + 2]
                nn = lo | (hi << 8)
                return f"jp {nn:#06x}", 3
            if y == 1:
                return "CB-prefix", 1
            if y == 2:
                n = rom[addr + 1]
                return f"out ({n:#04x}),a", 2
            if y == 3:
                n = rom[addr + 1]
                return f"in a,({n:#04x})", 2
            if y == 4:
                return "ex (sp),hl", 1
            if y == 5:
                return "ex de,hl", 1
            if y == 6:
                return "di", 1
            if y == 7:
                return "ei", 1
        if z == 4:
            lo, hi = rom[addr + 1], rom[addr + 2]
            nn = lo | (hi << 8)
            return f"call {CC[y]},{nn:#06x}", 3
        if z == 5:
            if q == 0:
                return f"push {RP2[p]}", 1
            if p == 0:
                lo, hi = rom[addr + 1], rom[addr + 2]
                nn = lo | (hi << 8)
                return f"call {nn:#06x}", 3
            return "ED/DD/FD-prefix", 1
        if z == 6:
            n = rom[addr + 1]
            return f"{ALU[y]}{n:#04x}", 2
        if z == 7:
            return f"rst {y*8:#04x}", 1

    return f"DB {b0:#04x}", 1
