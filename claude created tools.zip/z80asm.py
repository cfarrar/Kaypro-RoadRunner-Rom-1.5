#!/usr/bin/env python3
"""
Purpose-built two-pass Z80 assembler for kaypro_II_roadrunner_1_5.z80.

Supports exactly the instruction/directive/expression subset used by that
source file (verified by grepping the file for every mnemonic and operand
form before writing this). Not a general-purpose Z80 assembler.
"""
import re
import sys
import hashlib

INFILE = sys.argv[1] if len(sys.argv) > 1 else "kaypro_II_roadrunner_1_5.z80"
ROM_SIZE = 4096

# ----------------------------------------------------------------------
# Low level line splitting helpers (quote-aware, since strings can embed
# commas and the ';' comment character never appears inside a quote in
# this file, but we stay quote-aware for comments too, for safety).
# ----------------------------------------------------------------------

def strip_comment(line):
    out = []
    in_quote = False
    for c in line:
        if c == "'":
            in_quote = not in_quote
            out.append(c)
        elif c == ';' and not in_quote:
            break
        else:
            out.append(c)
    return ''.join(out)


def split_commas(s):
    parts = []
    cur = []
    in_quote = False
    for c in s:
        if c == "'":
            in_quote = not in_quote
            cur.append(c)
        elif c == ',' and not in_quote:
            parts.append(''.join(cur))
            cur = []
        else:
            cur.append(c)
    parts.append(''.join(cur))
    return [p.strip() for p in parts]


# ----------------------------------------------------------------------
# Expression tokenizer / recursive-descent evaluator.
# Grammar: expr := shiftexpr (('+'|'-') shiftexpr)*
#          shiftexpr := unary (('shl'|'shr') unary)*
#          unary := 'not' unary | primary
#          primary := NUM | CHAR | IDENT | '(' expr ')' | '-' primary
# ----------------------------------------------------------------------

TOK_HEX = re.compile(r'[0-9][0-9A-Fa-f]*[Hh]')
TOK_DEC = re.compile(r'[0-9]+')
TOK_ID = re.compile(r'[A-Za-z_][A-Za-z0-9_]*')


def tokenize(s):
    tokens = []
    i, n = 0, len(s)
    while i < n:
        c = s[i]
        if c.isspace():
            i += 1
            continue
        if c == "'":
            if i + 2 < n and s[i + 2] == "'":
                tokens.append(('CHAR', s[i + 1]))
                i += 3
                continue
            raise ValueError(f"bad char literal in expr: {s!r}")
        m = TOK_HEX.match(s, i)
        if m:
            tokens.append(('NUM', int(m.group(0)[:-1], 16)))
            i = m.end()
            continue
        m = TOK_DEC.match(s, i)
        if m:
            tokens.append(('NUM', int(m.group(0))))
            i = m.end()
            continue
        m = TOK_ID.match(s, i)
        if m:
            word = m.group(0)
            wl = word.lower()
            if wl == 'shl':
                tokens.append(('SHL', None))
            elif wl == 'shr':
                tokens.append(('SHR', None))
            elif wl == 'not':
                tokens.append(('NOT', None))
            else:
                tokens.append(('ID', word))
            i = m.end()
            continue
        if c in '+-()':
            tokens.append((c, None))
            i += 1
            continue
        raise ValueError(f"tokenize error at {s[i:]!r} in {s!r}")
    return tokens


def eval_expr(s, symtab):
    tokens = tokenize(s)
    pos = [0]

    def peek():
        return tokens[pos[0]] if pos[0] < len(tokens) else (None, None)

    def advance():
        t = tokens[pos[0]]
        pos[0] += 1
        return t

    def parse_primary():
        t, v = peek()
        if t == 'NUM':
            advance()
            return v
        if t == 'CHAR':
            advance()
            return ord(v)
        if t == 'ID':
            advance()
            return symtab[v]
        if t == 'NOT':
            advance()
            return (~parse_unary()) & 0xFFFF
        if t == '-':
            advance()
            return -parse_primary()
        if t == '(':
            advance()
            val = parse_add()
            t2, _ = advance()
            if t2 != ')':
                raise ValueError(f"expected ')' in {s!r}")
            return val
        raise ValueError(f"parse error at {(t, v)} in {s!r}")

    def parse_unary():
        t, _ = peek()
        if t == 'NOT':
            advance()
            return (~parse_unary()) & 0xFFFF
        return parse_primary()

    def parse_shift():
        val = parse_unary()
        while True:
            t, _ = peek()
            if t == 'SHL':
                advance()
                val = (val << parse_unary()) & 0xFFFF
            elif t == 'SHR':
                advance()
                val = (val >> parse_unary()) & 0xFFFF
            else:
                return val

    def parse_add():
        val = parse_shift()
        while True:
            t, _ = peek()
            if t == '+':
                advance()
                val = val + parse_shift()
            elif t == '-':
                advance()
                val = val - parse_shift()
            else:
                return val

    result = parse_add()
    if pos[0] != len(tokens):
        raise ValueError(f"trailing tokens in expr {s!r}")
    return result


# ----------------------------------------------------------------------
# Register/condition tables
# ----------------------------------------------------------------------

REG8 = {'b': 0, 'c': 1, 'd': 2, 'e': 3, 'h': 4, 'l': 5, 'a': 7}
REG16 = {'bc': 0, 'de': 1, 'hl': 2, 'sp': 3}
REG16_PUSH = {'bc': 0, 'de': 1, 'hl': 2, 'af': 3}
COND8 = {'nz': 0, 'z': 1, 'nc': 2, 'c': 3, 'po': 4, 'pe': 5, 'p': 6, 'm': 7}
COND4 = {'nz': 0, 'z': 1, 'nc': 2, 'c': 3}
ED16_LD_FROM_MEM = {'bc': 0x4B, 'de': 0x5B, 'hl': 0x6B, 'sp': 0x7B}
ED16_LD_TO_MEM = {'bc': 0x43, 'de': 0x53, 'hl': 0x63, 'sp': 0x73}


def reg8_code(tok):
    tl = tok.lower()
    if tl == '(hl)':
        return 6
    return REG8[tl]


def is_reg8_or_hlmem(tok):
    tl = tok.lower()
    return tl == '(hl)' or tl in REG8


def alu_encode(op, operand, resolve):
    if is_reg8_or_hlmem(operand):
        return [0x80 + op * 8 + reg8_code(operand)]
    n = resolve(operand)
    return [0xC6 + op * 8, n & 0xFF]


def encode_ld(ops, resolve, addr):
    dst, src = ops[0], ops[1]
    dstl, srcl = dst.lower(), src.lower()

    if dstl in REG8 or dstl == '(hl)':
        dst_code = reg8_code(dst)
        if srcl in REG8 or srcl == '(hl)':
            src_code = reg8_code(src)
            return [0x40 + dst_code * 8 + src_code]
        if dstl == 'a' and srcl == '(bc)':
            return [0x0A]
        if dstl == 'a' and srcl == '(de)':
            return [0x1A]
        if dstl == 'a' and srcl.startswith('(') and srcl.endswith(')'):
            val = resolve(src[1:-1])
            return [0x3A, val & 0xFF, (val >> 8) & 0xFF]
        # immediate
        n = resolve(src)
        return [0x06 + dst_code * 8, n & 0xFF]

    if dstl == '(bc)' and srcl == 'a':
        return [0x02]
    if dstl == '(de)' and srcl == 'a':
        return [0x12]
    if dstl.startswith('(') and dstl.endswith(')') and srcl == 'a':
        val = resolve(dst[1:-1])
        return [0x32, val & 0xFF, (val >> 8) & 0xFF]

    if dstl in REG16:
        if srcl.startswith('(') and srcl.endswith(')'):
            val = resolve(src[1:-1])
            if dstl == 'hl':
                return [0x2A, val & 0xFF, (val >> 8) & 0xFF]
            return [0xED, ED16_LD_FROM_MEM[dstl], val & 0xFF, (val >> 8) & 0xFF]
        if dstl == 'sp' and srcl == 'hl':
            return [0xF9]
        val = resolve(src)
        return [0x01 + REG16[dstl] * 16, val & 0xFF, (val >> 8) & 0xFF]

    if dstl.startswith('(') and dstl.endswith(')') and srcl in REG16:
        val = resolve(dst[1:-1])
        if srcl == 'hl':
            return [0x22, val & 0xFF, (val >> 8) & 0xFF]
        return [0xED, ED16_LD_TO_MEM[srcl], val & 0xFF, (val >> 8) & 0xFF]

    raise ValueError(f"unhandled ld operands: {dst!r},{src!r}")


def encode_instruction(mnem, operand_str, resolve, addr):
    """addr = address of the START of this instruction (for relative jumps)."""
    ops = split_commas(operand_str) if operand_str.strip() else []

    m = mnem.lower()

    simple = {
        'nop': [0x00], 'halt': [0x76], 'di': [0xF3], 'ei': [0xFB],
        'rra': [0x1F],
        'ldir': [0xED, 0xB0], 'lddr': [0xED, 0xB8],
        'cpir': [0xED, 0xB1], 'ini': [0xED, 0xA2], 'outi': [0xED, 0xA3],
    }
    if m in simple and not ops:
        return simple[m]

    if m == 'ret':
        if not ops:
            return [0xC9]
        return [0xC0 + COND8[ops[0].lower()] * 8]

    if m == 'push':
        return [0xC5 + REG16_PUSH[ops[0].lower()] * 16]
    if m == 'pop':
        return [0xC1 + REG16_PUSH[ops[0].lower()] * 16]

    if m == 'ex':
        a0, a1 = ops[0].lower(), ops[1].lower()
        if a0 == 'de' and a1 == 'hl':
            return [0xEB]
        if a0 == '(sp)' and a1 == 'hl':
            return [0xE3]
        raise ValueError(f"unhandled ex operands: {ops}")

    if m == 'djnz':
        target = resolve(ops[0])
        disp = target - (addr + 2)
        if not (-128 <= disp <= 127):
            raise ValueError(f"djnz out of range at {addr:04x}: disp={disp}")
        return [0x10, disp & 0xFF]

    if m == 'jr':
        if len(ops) == 1:
            target = resolve(ops[0])
            disp = target - (addr + 2)
            if not (-128 <= disp <= 127):
                raise ValueError(f"jr out of range at {addr:04x}: disp={disp}")
            return [0x18, disp & 0xFF]
        cc = COND4[ops[0].lower()]
        target = resolve(ops[1])
        disp = target - (addr + 2)
        if not (-128 <= disp <= 127):
            raise ValueError(f"jr cc out of range at {addr:04x}: disp={disp}")
        return [0x20 + cc * 8, disp & 0xFF]

    if m == 'jp':
        if len(ops) == 1:
            val = resolve(ops[0])
            return [0xC3, val & 0xFF, (val >> 8) & 0xFF]
        cc = COND8[ops[0].lower()]
        val = resolve(ops[1])
        return [0xC2 + cc * 8, val & 0xFF, (val >> 8) & 0xFF]

    if m == 'call':
        if len(ops) == 1:
            val = resolve(ops[0])
            return [0xCD, val & 0xFF, (val >> 8) & 0xFF]
        cc = COND8[ops[0].lower()]
        val = resolve(ops[1])
        return [0xC4 + cc * 8, val & 0xFF, (val >> 8) & 0xFF]

    if m in ('inc', 'dec'):
        o = ops[0].lower()
        if o in REG8 or o == '(hl)':
            base = 0x04 if m == 'inc' else 0x05
            return [base + reg8_code(o) * 8]
        if o in REG16:
            base = 0x03 if m == 'inc' else 0x0B
            return [base + REG16[o] * 16]
        raise ValueError(f"unhandled {m} operand: {ops}")

    if m == 'add':
        o0 = ops[0].lower()
        if o0 == 'a':
            return alu_encode(0, ops[1], resolve)
        if o0 == 'hl':
            return [0x09 + REG16[ops[1].lower()] * 16]
        raise ValueError(f"unhandled add operands: {ops}")

    if m == 'sbc':
        o0 = ops[0].lower()
        if o0 == 'hl':
            return [0xED, 0x42 + REG16[ops[1].lower()] * 16]
        if o0 == 'a':
            return alu_encode(3, ops[1], resolve)
        raise ValueError(f"unhandled sbc operands: {ops}")

    if m in ('and', 'or', 'xor', 'sub', 'cp'):
        opnum = {'and': 4, 'xor': 5, 'or': 6, 'sub': 2, 'cp': 7}[m]
        return alu_encode(opnum, ops[0], resolve)

    if m == 'srl':
        return [0xCB, 0x38 + reg8_code(ops[0])]

    if m in ('bit', 'res', 'set'):
        b = resolve(ops[0])
        r = ops[1].lower()
        base = {'bit': 0x40, 'res': 0x80, 'set': 0xC0}[m]
        return [0xCB, base + b * 8 + reg8_code(r)]

    if m == 'out':
        o0 = ops[0].lower()
        if o0 == '(c)':
            return [0xED, 0x41 + REG8[ops[1].lower()] * 8]
        n = resolve(ops[0][1:-1])
        return [0xD3, n & 0xFF]

    if m == 'in':
        o1 = ops[1].lower()
        n = resolve(ops[1][1:-1])
        return [0xDB, n & 0xFF]

    if m == 'ld':
        return encode_ld(ops, resolve, addr)

    raise ValueError(f"unhandled mnemonic: {mnem!r} operands={ops}")


# ----------------------------------------------------------------------
# defb / defw / defs handling
# ----------------------------------------------------------------------

def encode_defb(operand_str, resolve):
    out = []
    for item in split_commas(operand_str):
        item = item.strip()
        if len(item) >= 2 and item[0] == "'" and item[-1] == "'":
            for ch in item[1:-1]:
                out.append(ord(ch) & 0xFF)
        else:
            out.append(resolve(item) & 0xFF)
    return out


def encode_defw(operand_str, resolve):
    out = []
    for item in split_commas(operand_str):
        val = resolve(item.strip())
        out.append(val & 0xFF)
        out.append((val >> 8) & 0xFF)
    return out


# ----------------------------------------------------------------------
# Line parsing: split off an optional column-0 label.
# ----------------------------------------------------------------------

def parse_line(raw):
    line = strip_comment(raw).rstrip('\n')
    if line.strip() == '':
        return None, ''
    if line[0] not in (' ', '\t'):
        m = re.match(r'([A-Za-z_][A-Za-z0-9_]*)\s*:?\s*(.*)', line)
        if not m:
            raise ValueError(f"cannot parse label line: {raw!r}")
        label, rest = m.group(1), m.group(2)
        return label, rest.strip()
    return None, line.strip()


class DummyDict(dict):
    """Returns 0 for any missing key, used for pass-1 sizing only."""
    def __missing__(self, key):
        return 0


def compute_size(mnem, operand_str, dummy_resolve):
    m = mnem.lower()
    if m == 'defb':
        return len(encode_defb(operand_str, dummy_resolve))
    if m == 'defw':
        return len(encode_defw(operand_str, dummy_resolve))
    # instructions: value never affects size, dummy resolve is safe,
    # EXCEPT relative jumps, whose encode raises on out-of-range using
    # a bogus dummy target (0); guard by resolving displacement loosely.
    if m in ('jr', 'djnz'):
        ops = split_commas(operand_str)
        return 2  # jr/djnz are always opcode+displacement = 2 bytes
    return len(encode_instruction(mnem, operand_str, dummy_resolve, 0))


def main():
    with open(INFILE) as f:
        raw_lines = f.readlines()

    symtab = {}
    pc = 0
    lines_info = []  # (label, mnem, operand_str, addr_at_start_of_line)

    dummy_resolve = lambda expr: eval_expr(expr, DummyDict())

    # Two location counters: 'rom_pc' tracks the true running position within
    # the 4096-byte ROM image; 'pc' is the *effective* counter used for label
    # addresses at the current line. An `org` to an address >= ROM_SIZE (a
    # RAM symbol like BootSectorScratch/DiskBiosState/DriveParamCache/
    # RuntimeConfig) opens a non-persistent "RAM bookkeeping" excursion used
    # purely to compute variable offsets via `defs` - it does not advance or
    # replace rom_pc. As soon as real ROM content (an instruction, defb, or
    # defw - never encountered mid-RAM-block in this source) appears again,
    # we snap back to rom_pc automatically, since such content cannot
    # actually live at a RAM address in the ROM image. An `org` to an
    # address < ROM_SIZE always resumes/re-anchors rom_pc directly.
    rom_pc = 0
    mode = 'rom'  # or 'ram'

    stopped = False
    for raw in raw_lines:
        if stopped:
            break
        label, rest = parse_line(raw)
        if label is None and rest == '':
            continue

        mnem, operand_str = '', ''
        if rest:
            parts = rest.split(None, 1)
            mnem = parts[0]
            operand_str = parts[1] if len(parts) > 1 else ''

        ml = mnem.lower()

        if ml == 'equ':
            if label is None:
                raise ValueError(f"equ with no label: {raw!r}")
            val = eval_expr(operand_str, symtab)
            symtab[label] = val & 0xFFFF
            lines_info.append((None, 'equ', operand_str, pc, label))
            continue

        # Real code/data content forces us back into ROM mode if a RAM
        # excursion is currently open (see comment above).
        if ml in ('defb', 'defw') or (ml not in ('', '.z80', 'org', 'end', 'defs')):
            if mode == 'ram':
                mode = 'rom'
                pc = rom_pc

        addr_here = pc

        # record label -> current PC (code/data label, not equ)
        if label is not None:
            symtab[label] = pc & 0xFFFF

        if ml == '':
            # label-only line
            lines_info.append((label, '', '', addr_here, None))
            continue

        if ml == '.z80':
            lines_info.append((label, '.z80', '', addr_here, None))
            continue

        if ml == 'org':
            new_pc = eval_expr(operand_str, symtab) & 0xFFFF
            if new_pc < ROM_SIZE:
                mode = 'rom'
                rom_pc = new_pc
                pc = rom_pc
            else:
                mode = 'ram'
                pc = new_pc
            lines_info.append((label, 'org', operand_str, addr_here, None))
            continue

        if ml == 'end':
            lines_info.append((label, 'end', '', addr_here, None))
            stopped = True
            continue

        if ml == 'defs':
            count = eval_expr(operand_str, symtab)
            lines_info.append((label, 'defs', operand_str, addr_here, None))
            pc += count
            if mode == 'rom':
                rom_pc = pc
            continue

        if ml in ('defb', 'defw'):
            size = compute_size(ml, operand_str, dummy_resolve)
            lines_info.append((label, ml, operand_str, addr_here, None))
            pc += size
            rom_pc = pc  # mode is guaranteed 'rom' here (see forced switch above)
            continue

        # regular instruction
        size = compute_size(ml, operand_str, dummy_resolve)
        lines_info.append((label, ml, operand_str, addr_here, None))
        pc += size
        rom_pc = pc

    # ---------------- Pass 2: emit bytes ----------------
    rom = bytearray([0xFF] * ROM_SIZE)
    max_addr_used = -1

    def real_resolve(expr):
        return eval_expr(expr, symtab)

    for label, mnem, operand_str, addr, equ_label in lines_info:
        ml = mnem.lower()
        if ml in ('', 'equ', '.z80', 'org', 'end'):
            continue
        if ml == 'defs':
            continue  # no bytes emitted, RAM-only reservation
        if ml == 'defb':
            data = encode_defb(operand_str, real_resolve)
        elif ml == 'defw':
            data = encode_defw(operand_str, real_resolve)
        else:
            data = encode_instruction(mnem, operand_str, real_resolve, addr)

        for i, b in enumerate(data):
            a = addr + i
            if 0 <= a < ROM_SIZE:
                rom[a] = b & 0xFF
                if a > max_addr_used:
                    max_addr_used = a

    return rom, symtab, max_addr_used, lines_info


if __name__ == '__main__':
    rom, symtab, max_addr_used, lines_info = main()
    with open('/home/claude/reassembled.rom', 'wb') as f:
        f.write(rom)
    h = hashlib.sha256(rom).hexdigest()
    print(f"Highest ROM address written: {max_addr_used:#06x}")
    print(f"Output size: {len(rom)} bytes")
    print(f"SHA-256: {h}")
